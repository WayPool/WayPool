function t(){window.innerWidth>768||document.documentElement.classList.contains("dark")&&(console.log("[GrayFix] Iniciando corrección de fondos grises..."),r("span.bg-slate-700, span.rounded-lg, span.px-4"),r("div > span.px-4.py-2.rounded-lg, div > span.px-4.py-2"),r("div.p-3.rounded-full, div.p-3.rounded-full.w-fit"),r(".dark-feature-card h3"),r(".dark-feature-card div.flex.items-center.justify-center"),r("h3 span.bg-slate-700, h3 span.px-4"),i(),console.log("[GrayFix] Corrección de fondos grises completada"))}function r(e){const s=document.querySelectorAll(e);s.forEach(o=>{o.setAttribute("style",`
      background-color: rgb(19, 24, 54) !important; 
      border: 1px solid rgb(39, 46, 79) !important;
      color: white !important;
    `),o.classList.add("gray-fixed")}),console.log(`[GrayFix] Corregidos ${s.length} elementos con selector: ${e}`)}function i(){const e=document.createElement("style");e.id="gray-fix-aggressive",e.textContent=`
    @media (max-width: 767px) {
      /* Corrección específica para "Minimize Risks" */
      html.dark span.px-4.py-2.rounded-lg,
      html.dark span.px-4.py-2,
      html.dark [class*="px-4"][class*="py-2"],
      html.dark span[class*="bg-slate"],
      html.dark span[class*="rounded"] {
        background-color: rgb(19, 24, 54) !important;
        border: 1px solid rgb(39, 46, 79) !important;
        color: white !important;
      }
      
      /* Forzar colores correctos para todos los spans dentro de h3 */
      html.dark h3 span {
        background-color: rgb(19, 24, 54) !important;
        border: 1px solid rgb(39, 46, 79) !important;
      }
      
      /* Forzar iconos con fondo correcto */
      html.dark div[class*="w-16"][class*="h-16"],
      html.dark div[class*="rounded-full"],
      html.dark div[class*="justify-center"][class*="items-center"] svg {
        background-color: rgb(19, 24, 54) !important;
        border: 1px solid rgb(39, 46, 79) !important;
      }
    }
  `,document.head.appendChild(e),console.log("[GrayFix] CSS agresivo inyectado")}function c(){t(),setTimeout(t,500),setTimeout(t,1500),setTimeout(t,3e3),new MutationObserver(s=>{let o=!1;s.forEach(n=>{n.type==="childList"&&n.addedNodes.length>0&&n.addedNodes.forEach(d=>{if(d.nodeType===1){const a=d;(a.classList.contains("rounded-lg")||a.classList.contains("rounded-full")||a.tagName==="SPAN")&&(o=!0)}})}),o&&t()}).observe(document.body,{childList:!0,subtree:!0}),console.log("[GrayFix] Observador de mutaciones activado")}export{t as initGrayFix,c as setupRecurringFix};
